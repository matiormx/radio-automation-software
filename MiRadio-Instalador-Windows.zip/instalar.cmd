@echo off
setlocal
title Instalador de MiRadio

set "DEST=%LOCALAPPDATA%\MiRadio"
echo Instalando MiRadio en %DEST% ...

if not exist "%DEST%" mkdir "%DEST%"

copy /Y "%~dp0MiRadio.exe" "%DEST%\MiRadio.exe" >nul
if errorlevel 1 (
    echo Error: no se pudo copiar MiRadio.exe.
    pause
    exit /b 1
)

rem Acceso directo en el escritorio
powershell -NoProfile -Command ^
 "$ws = New-Object -ComObject WScript.Shell;" ^
 "$d = [Environment]::GetFolderPath('Desktop');" ^
 "$s = $ws.CreateShortcut(\"$d\MiRadio.lnk\");" ^
 "$s.TargetPath = \"$env:LOCALAPPDATA\MiRadio\MiRadio.exe\";" ^
 "$s.WorkingDirectory = \"$env:LOCALAPPDATA\MiRadio\";" ^
 "$s.Save()"

rem Acceso directo en el menu de inicio
set "MENU=%APPDATA%\Microsoft\Windows\Start Menu\Programs"
if not exist "%MENU%\MiRadio" mkdir "%MENU%\MiRadio"
powershell -NoProfile -Command ^
 "$ws = New-Object -ComObject WScript.Shell;" ^
 "$m = \"$env:APPDATA\Microsoft\Windows\Start Menu\Programs\MiRadio\";" ^
 "$s = $ws.CreateShortcut(\"$m\MiRadio.lnk\");" ^
 "$s.TargetPath = \"$env:LOCALAPPDATA\MiRadio\MiRadio.exe\";" ^
 "$s.WorkingDirectory = \"$env:LOCALAPPDATA\MiRadio\";" ^
 "$s.Save()"

echo.
echo Listo. Ya puedes arrancar MiRadio desde el escritorio.
echo Instalado sin permisos de administrador.
pause
