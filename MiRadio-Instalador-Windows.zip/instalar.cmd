@echo off
setlocal EnableExtensions
title Instalador de MiRadio

set "VERSION=0.4.1"
set "DEST=%LOCALAPPDATA%\MiRadio"

echo Instalando MiRadio %VERSION% en %DEST% ...

rem Cierra una instancia abierta para poder reemplazar el ejecutable
taskkill /IM MiRadio.exe /F >nul 2>&1
timeout /t 1 /nobreak >nul

if not exist "%DEST%" mkdir "%DEST%"

copy /Y "%~dp0MiRadio.exe" "%DEST%\MiRadio.exe" >nul
if errorlevel 1 (
    echo Error: no se pudo copiar MiRadio.exe.
    pause
    exit /b 1
)
copy /Y "%~dp0desinstalar.cmd" "%DEST%\desinstalar.cmd" >nul

rem Acceso directo en el escritorio
powershell -NoProfile -Command ^
 "$ws = New-Object -ComObject WScript.Shell;" ^
 "$d = [Environment]::GetFolderPath('Desktop');" ^
 "$s = $ws.CreateShortcut(\"$d\MiRadio.lnk\");" ^
 "$s.TargetPath = \"$env:LOCALAPPDATA\MiRadio\MiRadio.exe\";" ^
 "$s.WorkingDirectory = \"$env:LOCALAPPDATA\MiRadio\";" ^
 "$s.Save()"

rem Acceso directo en el menu de inicio
set "MENU=%APPDATA%\Microsoft\Windows\Start Menu\Programs"
if not exist "%MENU%\MiRadio" mkdir "%MENU%\MiRadio"
powershell -NoProfile -Command ^
 "$ws = New-Object -ComObject WScript.Shell;" ^
 "$m = \"$env:APPDATA\Microsoft\Windows\Start Menu\Programs\MiRadio\";" ^
 "$s = $ws.CreateShortcut(\"$m\MiRadio.lnk\");" ^
 "$s.TargetPath = \"$env:LOCALAPPDATA\MiRadio\MiRadio.exe\";" ^
 "$s.WorkingDirectory = \"$env:LOCALAPPDATA\MiRadio\";" ^
 "$s.Save()"

rem Entrada en "Aplicaciones instaladas" (HKCU: no pide administrador)
set "UNINST=HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\MiRadio"
reg add "%UNINST%" /f /v DisplayName /d "MiRadio" >nul
reg add "%UNINST%" /f /v DisplayVersion /d "%VERSION%" >nul
reg add "%UNINST%" /f /v Publisher /d "MiRadio" >nul
reg add "%UNINST%" /f /v InstallLocation /d "%DEST%" >nul
reg add "%UNINST%" /f /v DisplayIcon /d "%DEST%\MiRadio.exe" >nul
reg add "%UNINST%" /f /v UninstallString /d "\"%DEST%\desinstalar.cmd\"" >nul
reg add "%UNINST%" /f /v EstimatedSize /t REG_DWORD /d 5400 >nul
reg add "%UNINST%" /f /v NoModify /t REG_DWORD /d 1 >nul
reg add "%UNINST%" /f /v NoRepair /t REG_DWORD /d 1 >nul

if errorlevel 1 (
    echo Aviso: no se pudo registrar en Aplicaciones instaladas.
    echo La app funciona igual; el desinstalador esta en %DEST%\desinstalar.cmd
)

echo.
echo Listo. Ya puedes abrir MiRadio desde el escritorio.
echo Instalado sin permisos de administrador.
pause
