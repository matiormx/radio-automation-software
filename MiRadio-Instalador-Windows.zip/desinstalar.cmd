@echo off
setlocal EnableExtensions
title Desinstalador de MiRadio

taskkill /IM MiRadio.exe /F >nul 2>&1
timeout /t 1 /nobreak >nul

rem Accesos directos
if exist "%USERPROFILE%\Desktop\MiRadio.lnk" del /q "%USERPROFILE%\Desktop\MiRadio.lnk" >nul
if exist "%APPDATA%\Microsoft\Windows\Start Menu\Programs\MiRadio" ^
    rmdir /s /q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\MiRadio" >nul

rem Entrada de "Aplicaciones instaladas"
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\MiRadio" /f >nul 2>&1

echo.
echo MiRadio se ha desinstalado.
echo.
echo Tus canciones, listas y ajustes se conservan en:
echo   %LOCALAPPDATA%\com.miradio.app
echo.
echo Si tambien quieres borrarlos (no se puede deshacer):
echo   rmdir /s /q "%LOCALAPPDATA%\com.miradio.app"
echo.
pause

rem Borra la carpeta del programa cuando este script ya se haya cerrado
start "" /b cmd /c "ping -n 3 127.0.0.1 >nul & rmdir /s /q \"%LOCALAPPDATA%\MiRadio\""
exit /b 0
