@echo off
setlocal
title Desinstalador de MiRadio

set "DEST=%LOCALAPPDATA%\MiRadio"
echo Desinstalando MiRadio de %DEST% ...

if exist "%DEST%\MiRadio.exe" del /F "%DEST%\MiRadio.exe"
if exist "%DEST%" rmdir "%DEST%"

rem Quitar accesos directos
del /F "%USERPROFILE%\Desktop\MiRadio.lnk" 2>nul
del /F "%APPDATA%\Microsoft\Windows\Start Menu\Programs\MiRadio\MiRadio.lnk" 2>nul
if exist "%APPDATA%\Microsoft\Windows\Start Menu\Programs\MiRadio" rmdir "%APPDATA%\Microsoft\Windows\Start Menu\Programs\MiRadio"

echo Listo. MiRadio desinstalado.
pause
